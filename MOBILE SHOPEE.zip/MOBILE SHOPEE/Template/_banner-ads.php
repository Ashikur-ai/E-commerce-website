<!--Bannner Ads-->

<section id="banner_adds">
    <div class="container py-5">
        <img src="./assets/banner1-cr-500x150.jpg" alt="img-banner1">
        <img src="./assets/banner2-cr-500x150.jpg" alt="img-banner1">
    </div>
</section>
<!--!Bannner Ads-->